#ifndef _MAIN_H
#define _MAIN_H

#include <iostream>

#include "GL\glew.h"
#include "GLFW\glfw3.h"

#include "GLM\glm.hpp"

#include "OpenGL-Tutorials\shader.hpp"

#endif // !MAIN_H

