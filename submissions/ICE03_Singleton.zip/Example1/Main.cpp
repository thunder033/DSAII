#include "Main.h"
using namespace std;

void main(void) {
	cout << "Hello Word" << endl;
	cout << "Press Enter to continue...";
	getchar();
}